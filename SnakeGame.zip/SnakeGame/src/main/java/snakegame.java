
public class snakegame {
	public static void main(String[] args) {
		new GameFrame();
	}
}
