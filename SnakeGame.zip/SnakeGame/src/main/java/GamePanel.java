import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener, KeyListener{
	private static final int screenwidth = 600;
	private static final int screenheight = 600;
	private static final int unitsize = 25;
	private static final int gameunit = (screenwidth*screenheight/unitsize);
	private static final int delay = 100;
	
	private final int x[] = new int[gameunit];
	private final int y[] = new int[gameunit];
	
	private int bodypart = 5;
	private int appleEaten;
	
	private int apple_x;
	private int apple_y;
	
	private char direction = 'R';
	private boolean running  = false;
	private Timer timer ;
	
	private Random random;

	public GamePanel() {
		random=new Random();
		this.setPreferredSize(new Dimension(screenwidth,screenheight));
		this.setBackground(Color.black);
		this.setFocusable(true);
		this.addKeyListener(this);
		startGame();
	}
	
	public void startGame(){
		newApple();
		running = true;
		timer = new Timer(delay,this);
		timer.start();		
	}
	
	public void paintComponent(Graphics G){
		super.paintComponent(G);
		draw(G);
	}
	
	public void draw(Graphics G) {
		if(running) {
			G.setColor(Color.red);
			G.fillOval(apple_x, apple_y, unitsize, unitsize);
			for(int i = 0; i<bodypart; i++) {
				if(i==0) {
					G.setColor(Color.green);
					G.fillRect(x[i], y[i], unitsize, unitsize);
				}
				else {
					G.setColor(new Color(45, 180, 0));
					G.fillRect(x[i], y[i], unitsize, unitsize);
				}
			}
			G.setColor(Color.red);
			G.setFont(new Font("Ink Free", Font.BOLD, 40));
			FontMetrics metrics = getFontMetrics(G.getFont());
			G.drawString("Score " + appleEaten, (screenwidth - metrics.stringWidth("Score " + appleEaten))/2, G.getFont().getSize());
		}
		else {
			gameOver(G);
		}
	}
	
	public void newApple() {
		apple_x = random.nextInt((int)(screenwidth/unitsize))*unitsize;
		apple_y = random.nextInt((int)(screenheight/unitsize))*unitsize;		
	}
	
	public void move() {
		for(int i = bodypart; i>0; i--) {
			x[i] = x[i-1];
			y[i] = y[i-1];
		}
		
		switch(direction) {
			case 'U':
				y[0] = y[0] - unitsize;
				break;
				
			case 'D':
				y[0] = y[0] + unitsize;
				break;
			
			case 'L':
				x[0] = x[0] - unitsize;
				break;
				
			case 'R':
				x[0] = x[0] + unitsize;
				break;			
		}		
	}
	
	public void checkApple() {
		if((x[0]==apple_x) && (y[0]==apple_y)) {
			bodypart++;
			appleEaten++;
			newApple();
		}
	}
	
	public void checkCollisions() {
		for(int i = bodypart; i>0; i--) {
			if((x[0]==x[i])&&(y[0]==y[i])) {
				running = false;
			}
		}
		if(x[0] < 0) {
			running = false;
		}
		
		if(x[0] >=screenwidth) {
			running = false;
		}
		
		if(y[0] < 0) {
			running = false;
		}
		
		if(y[0] >=screenheight) {
			running = false;
		}
		
		if(!running) {
			timer.stop();
		}
	}
	
	
	public void gameOver(Graphics G){
		G.setColor(Color.red);
		G.setFont(new Font("Ink Free", Font.BOLD, 75));
		FontMetrics metrics = getFontMetrics(G.getFont());
		G.drawString("Game Over", (screenwidth - metrics.stringWidth("Game Over"))/2,screenheight/2);
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		switch(e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				if(direction!='R') {
					direction = 'L';
				}
				break;
				
			case KeyEvent.VK_RIGHT:
				if(direction!='L') {
					direction = 'R';
				}
				break;
			
			case KeyEvent.VK_UP:
				if(direction!='D') {
					direction = 'U';
				}
				break;
				
			case KeyEvent.VK_DOWN:
				if(direction!='U') {
					direction = 'D';
				}
				break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(running) {
			move();
			checkApple();
			checkCollisions();
		}
		repaint();
	}
	
}
